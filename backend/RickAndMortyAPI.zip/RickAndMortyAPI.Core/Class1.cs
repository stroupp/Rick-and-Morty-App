﻿namespace RickAndMortyAPI.Core;

public class Class1
{

}
