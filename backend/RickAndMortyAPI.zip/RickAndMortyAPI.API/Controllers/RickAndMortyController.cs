using Microsoft.AspNetCore.Mvc;
using RickAndMortyAPI.Core.Interfaces;
using System.Threading.Tasks;

namespace RickAndMortyAPI.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RickAndMortyController : ControllerBase
    {
        private readonly IRickAndMortyService _rickAndMortyService;

        public RickAndMortyController(IRickAndMortyService rickAndMortyService)
        {
            _rickAndMortyService = rickAndMortyService;
        }

        [HttpGet("characters")]
        public async Task<IActionResult> GetCharacters()
        {
            var characters = await _rickAndMortyService.GetCharactersAsync();
            return Ok(characters);
        }

        [HttpGet("episodes")]
        public async Task<IActionResult> GetEpisodes()
        {
            var episodes = await _rickAndMortyService.GetEpisodesAsync();
            return Ok(episodes);
        }
    }
}
