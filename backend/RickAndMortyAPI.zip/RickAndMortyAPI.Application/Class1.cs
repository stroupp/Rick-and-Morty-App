﻿namespace RickAndMortyAPI.Application;

public class Class1
{

}
