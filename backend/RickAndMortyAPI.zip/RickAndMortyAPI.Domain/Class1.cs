﻿namespace RickAndMortyAPI.Domain;

public class Class1
{

}
