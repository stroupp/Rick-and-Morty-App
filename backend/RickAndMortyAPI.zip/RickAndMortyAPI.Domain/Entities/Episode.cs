namespace RickAndMortyAPI.Domain.Entities
{
    public class Episode
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string AirDate { get; set; }
        public string EpisodeCode { get; set; }
        // Navigation property
        public ICollection<Character> Characters { get; set; }
    }
}
