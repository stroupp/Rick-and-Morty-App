using RickAndMortyAPI.Core.DTOs;
using RickAndMortyAPI.Core.Interfaces;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace RickAndMortyAPI.Infrastructure.Services
{
    public class RickAndMortyService : IRickAndMortyService
    {
        private readonly HttpClient _httpClient;
        private const string BaseUrl = "https://rickandmortyapi.com/api";

        public RickAndMortyService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IEnumerable<CharacterDto>> GetCharactersAsync()
        {
            var response = await _httpClient.GetFromJsonAsync<RickAndMortyApiResponse<CharacterDto>>($"{BaseUrl}/character");
            return response?.Results ?? new List<CharacterDto>();
        }

        public async Task<IEnumerable<EpisodeDto>> GetEpisodesAsync()
        {
            var response = await _httpClient.GetFromJsonAsync<RickAndMortyApiResponse<EpisodeDto>>($"{BaseUrl}/episode");
            return response?.Results ?? new List<EpisodeDto>();
        }
    }

    // Helper class for API response
    public class RickAndMortyApiResponse<T>
    {
        public IEnumerable<T> Results { get; set; }
    }
}
