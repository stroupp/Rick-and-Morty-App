﻿namespace RickAndMortyAPI.Infrastructure;

public class Class1
{

}
